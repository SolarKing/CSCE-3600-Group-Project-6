./project -sizeL1 16384 -sizeL2 32768 -type direct < big_trace.trace
