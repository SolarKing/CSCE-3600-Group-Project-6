./project -sizeL1 32768 -sizeL2 1000 -type direct < big_trace.trace
